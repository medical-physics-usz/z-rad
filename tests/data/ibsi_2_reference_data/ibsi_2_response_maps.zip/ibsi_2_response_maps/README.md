# IBSI II phase I response maps

This archive contains all 33 published NIfTI consensus response maps in
`reference_response_maps/`, including `10_b_1-ValidCRM.nii`.
Every voxel must agree within 1% of the reference map's intensity range.

Source: https://github.com/theibsi/ibsi_2_reference_data/tree/5404579fb3e0d17e8db421f0e82d64ce2432ec03

All maps and LICENSE were verified against upstream Git blob hashes at that
revision on 2026-09-09. They are redistributed unchanged under CC0 1.0 Universal;
see LICENSE and https://creativecommons.org/publicdomain/zero/1.0/.
Benchmark definitions: https://doi.org/10.48550/arXiv.2006.05470

Local changes: response maps were packaged separately from phase II feature
references; this README and SHA256SUMS were added. No map or license bytes changed.
Feature-reference CSVs remain outside this archive in the repository.

SHA256SUMS lists every file except itself, with paths relative to this directory.
Verify after extraction with `shasum -a 256 -c SHA256SUMS`.
