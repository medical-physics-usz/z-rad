IBSI-1 digital phantom 
===

This phantom was designed to test computation of image biomarkers. For details on use,
please consult the IBSI reference manual.

The phantom is available in NIfTI format and consists of the image itself (image) and its segmentation (mask). The DICOM mask was deprecated due to incorrect image spacing.

## License
The phantom is licensed under the Creative Commons Attribution 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/ or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

## Acknowledgments
Original design by Alex Zwanenburg. DICOM-format of the phantom courtesy to David Clunie.

## Repository adaptation

`LICENSE.md` was converted from Windows-1252 to UTF-8 on 2026-09-09.
The source bytes for curly quotation marks, apostrophes, and en dashes identify
Windows-1252 as the intended encoding. Only the character encoding was changed;
the license wording, punctuation, and line endings were preserved. The conversion
was verified by encoding the UTF-8 text back to Windows-1252 and comparing it
byte-for-byte with the original file.

Original `LICENSE.md` SHA-256: `c863fa4a2aa4d3152f4bcb58bb7bb63c95704805bbb4aec18cbea7c701d4f046`.

## Source and local changes

Source: [IBSI data_sets, ibsi_1_digital_phantom](https://github.com/theibsi/data_sets/tree/6da96021bc91faf4c0cb7fd7fa56a4225d2064a8/ibsi_1_digital_phantom).

The retained image files were verified against upstream Git blob hashes at
revision `6da96021bc91faf4c0cb7fd7fa56a4225d2064a8` on 2026-09-09.
This records a verified match, not an assertion about the original download date.

The upstream `dicom_deprecated` directory is omitted because its DICOM mask
has incorrect spacing. Both NIfTI files are unchanged. README additions and
the lossless license-encoding conversion are documented here.

`SHA256SUMS` records the SHA-256 of every distributed file in this directory,
including documentation and licensing, except the manifest itself. Paths are
relative to this directory. Verify with `shasum -a 256 -c SHA256SUMS` from here.
