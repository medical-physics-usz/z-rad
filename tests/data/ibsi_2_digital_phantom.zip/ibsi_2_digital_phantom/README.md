IBSI-2 digital phantoms
===

These phantoms were designed to test and standardise computation of convolutional filters. For details on use,
please consult the IBSI reference manual (https://arxiv.org/abs/2006.05470).

Nine phantoms are supplied in both DICOM and NIfTI formats: checkerboard,
empty, impulse, noise, orientation, pattern_1, pattern_2, pattern_3, and sphere.
Each DICOM series contains 64 slices. Eight NIfTI phantoms include a mask covering
the entire image volume; the orientation phantom has no supplied mask.

## Format relationship

Inspection with SimpleITK found matching dimensions, spacing, and direction,
but different origins: DICOM `(0, 0, -126)` and NIfTI `(0, 0, 0)`.
The voxel arrays agree after reversing the slice axis. These files must not be
treated as having identical physical geometry. The published response-map
benchmarks use the NIfTI inputs. The orientation phantom has dimensions
32 x 48 x 64; the other phantoms have dimensions 64 x 64 x 64.

## License
The phantom is licensed under the Creative Commons Attribution 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/ or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

## Acknowledgments
Original design by Alex Zwanenburg, for the Image Biomarker Standardisation Initiative (https://theibsi.github.io).

## Repository adaptation

`LICENSE.md` was converted from Windows-1252 to UTF-8 on 2026-09-09.
The source bytes for curly quotation marks, apostrophes, and en dashes identify
Windows-1252 as the intended encoding. Only the character encoding was changed;
the license wording, punctuation, and line endings were preserved. The conversion
was verified by encoding the UTF-8 text back to Windows-1252 and comparing it
byte-for-byte with the original file.

Original `LICENSE.md` SHA-256: `c863fa4a2aa4d3152f4bcb58bb7bb63c95704805bbb4aec18cbea7c701d4f046`.

## Source and local changes

Source: [IBSI data_sets, ibsi_2_digital_phantom](https://github.com/theibsi/data_sets/tree/6da96021bc91faf4c0cb7fd7fa56a4225d2064a8/ibsi_2_digital_phantom).

The retained image files were verified against upstream Git blob hashes at
revision `6da96021bc91faf4c0cb7fd7fa56a4225d2064a8` on 2026-09-09.
This records a verified match, not an assertion about the original download date.

All 576 DICOM files and 17 NIfTI files are unchanged. This README was expanded
to describe the supplied formats and their geometry. The lossless license
encoding conversion is documented above.

`SHA256SUMS` records the SHA-256 of every distributed file in this directory,
including documentation and licensing, except the manifest itself. Paths are
relative to this directory. Verify with `shasum -a 256 -c SHA256SUMS` from here.
